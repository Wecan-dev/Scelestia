<?php

get_header( 'shop' );

         

?>

<section class="shop-content">
<div class="shop-flex">
  <div class="filter">
     <div class="dropdown">
      <button class=" dropdown-toggle" type="button" id="dropdown1" data-toggle="dropdown">
        FILTROS
      </button>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="http://www.google.com">Google</a>
        <a class="dropdown-item" href="http://www.bing.com">Bing</a>
        <a class="dropdown-item" href="http://www.yahoo.com">Yahoo</a>
      </div>
    </div>  

    <div class="categorys-filter">
      <p>CATEGORÍAS</p>
      <ul class="cat-list">
        <li>Seda</li>
        <li>Seda</li>
        <li>Seda</li>
        <li>Seda</li>
      </ul>
    </div>

        <div class="categorys-filter">
      <p>PRECIO</p>
<form method="get" action="">
  <div class="price_slider_wrapper">
    <div class="price_slider ui-slider ui-slider-horizontal ui-widget ui-widget-content ui-corner-all" style=""><div class="ui-slider-range ui-widget-header ui-corner-all" style="left: 0%; width: 76.6819%;"></div><span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0" style="left: 0%;"></span><span class="ui-slider-handle ui-state-default ui-corner-all" tabindex="0" style="left: 76.6819%;"></span></div>
    <div class="price_slider_amount" data-step="10">
      <input type="text" id="min_price" name="min_price" value="15820" data-min="10000" placeholder="Precio mínimo" style="display: none;">
      <input type="text" id="max_price" name="max_price" value="46210" data-max="184500" placeholder="Precio máximo" style="display: none;">
            <button type="submit" class="button">Filtrar</button>
      <div class="price_label" style="">
        Precio: <span class="from">$10.000</span> — <span class="to">$143.810</span>
      </div>
            <div class="clear"></div>
    </div>
  </div>
</form>
    </div>
          <div class="categorys-filter">
      <p>COLORES</p>
  <ul class="cat-list">

    <!--    <li><input type="radio" id="color" name="gender" value="color"><span class="color-radio"></span> rojo</li>
        <li><input type="radio" id="color" name="gender" value="color"><span class="color-radio2"></span> Azul</li>
        <li>Amarillo</li> -->
        <ul>
    <li class="color-check">
        <input type='checkbox' value='1' name='radio' id='radio1'/>
       <label for='radio1'><span class="color-radio"></span></label> Rojo
    </li>
    <li class="color-check">
        <input type='checkbox' value='2' name='radio'  id='radio2'/>
        <label for='radio2'><span class="color-radio2"></span></label> Azul    </li>
    <li class="color-check">
        <input type='checkbox' value='3' name='radio'  id='radio3'/>
        <label for='radio3'><span class="color-radio2"></span></label> Verde
    </li>
</ul>
      </ul>
    </div>
  </div>
  <div class="cards-shop">
    <p class="show-results">Mostrando 1–16 de 22 resultados</p>
    <div class="cards-shop-flex">
          <div style="margin-bottom: 5%;" class="card-product ">
          <img src="assets/images/card1.png">
          <div class="text-product">
            <h5>Pijama Rosada Primaveral</h5>
            <p>$100.000</p>
            <div class="shop-btn">
              <a href="#">
                COMPRAR
              </a>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart w-size1 trans-0-4">
              <!-- Button -->
              <button class="btn-oficial2">
                Ver más
              </button>
            </div>
          </div>
        </div>
            <div style="margin-bottom: 5%;" class="card-product ">
          <img src="assets/images/card1.png">
          <div class="text-product">
            <h5>Pijama Rosada Primaveral</h5>
            <p>$100.000</p>
            <div class="shop-btn">
              <a href="#">
                COMPRAR
              </a>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart w-size1 trans-0-4">
              <!-- Button -->
              <button class="btn-oficial2">
                Ver más
              </button>
            </div>
          </div>
        </div>
            <div style="margin-bottom: 5%;" class="card-product ">
          <img src="assets/images/card1.png">
          <div class="text-product">
            <h5>Pijama Rosada Primaveral</h5>
            <p>$100.000</p>
            <div class="shop-btn">
              <a href="#">
                COMPRAR
              </a>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart w-size1 trans-0-4">
              <!-- Button -->
              <button class="btn-oficial2">
                Ver más
              </button>
            </div>
          </div>
        </div>
            <div style="margin-bottom: 5%;" class="card-product ">
          <img src="assets/images/card1.png">
          <div class="text-product">
            <h5>Pijama Rosada Primaveral</h5>
            <p>$100.000</p>
            <div class="shop-btn">
              <a href="#">
                COMPRAR
              </a>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart w-size1 trans-0-4">
              <!-- Button -->
              <button class="btn-oficial2">
                Ver más
              </button>
            </div>
          </div>
        </div>
            <div style="margin-bottom: 5%;" class="card-product ">
          <img src="assets/images/card1.png">
          <div class="text-product">
            <h5>Pijama Rosada Primaveral</h5>
            <p>$100.000</p>
            <div class="shop-btn">
              <a href="#">
                COMPRAR
              </a>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart w-size1 trans-0-4">
              <!-- Button -->
              <button class="btn-oficial2">
                Ver más
              </button>
            </div>
          </div>
        </div>
            <div style="margin-bottom: 5%;" class="card-product ">
          <img src="assets/images/card1.png">
          <div class="text-product">
            <h5>Pijama Rosada Primaveral</h5>
            <p>$100.000</p>
            <div class="shop-btn">
              <a href="#">
                COMPRAR
              </a>
            </div>
          </div>
          <div class="block2-overlay trans-0-4">
            <a href="#" class="block2-btn-addwishlist hov-pointer trans-0-4">
              <i class="fa fa-heart" aria-hidden="true"></i>
              <i class="icon-wishlist icon_heart dis-none" aria-hidden="true"></i>
            </a>

            <div class="block2-btn-addcart w-size1 trans-0-4">
              <!-- Button -->
              <button class="btn-oficial2">
                Ver más
              </button>
            </div>
          </div>
        </div>
    </div>
  </div>
</div>
</section>


<?php


get_footer( 'shop' );