<section class="comoda">
	<div class="box-mujer">
		<h6>ERES UNA MUJER</h6>
		<h3>CÓMODA<br>
			FRESCA<br>
		VALIOSA</h3>
	</div>
</section>