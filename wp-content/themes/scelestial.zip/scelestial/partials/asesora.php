<section style="margin-bottom: 10%;" class="asesora">
	<div class="asesora-img">
		<div class="div3"></div>
		<div class="text-img">
			<h6>ASESORAS</h6>
			<h3 style="margin-bottom: 31px;">Quiero ser asesora <br>
			</h3>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
			<div class="btn-oficial2">
				<a href="">
					Regístrate como vendedora
				</a>
			</div>
		</div>

		<div class="rose">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/rose.png">
		</div>

		<div class="hoja2">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/bck-asesora.png">
		</div>

		<div class="hoja3">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/bck-asesora2.png">
		</div>

	</div>
	<div class="pijama1">
		<p>PIJAMAS</p>
	</div>
	<div class="pijama2">
		<p>PIJAMAS</p>
	</div>
</section>