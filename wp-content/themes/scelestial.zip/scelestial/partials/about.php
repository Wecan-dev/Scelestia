
	<section id="about" class="container about">
		<div class="about_flex">
			<div class="about_info">
				<h6>ACERCA DE</h6>
				<h3>QUIENES <br>
				SOMOS</h3>			
				<div class="green">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/back-about.png">
				</div>
				<div class="img-about">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about2.png">
				</div>
				<div class="img-hoja">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/about.png">
				</div>

			</div>
			<div class="about_text">
				<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br><br>
					Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
					Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br> </p>

					<div class="btn-oficial">
						<a href="<?php echo bloginfo('url').'/index.php/nosotros';?>">
							Ver más <i style="color: #9fd0ae" class="fa fa-angle-right" aria-hidden="true"></i>
						</a>
					</div>
				</div>
			</div>
		</section>