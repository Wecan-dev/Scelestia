
<section class="instagram ">
	<div class="sec-title res-sec p-b-20 p-l-15 p-r-15">
		<h3 class="products-text t-center">
			@scelestial
		</h3>
	</div>

	<div class="">
		<div class="img-insta">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/insta.png">
		</div>
		<div class="img-insta">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/insta.png">
		</div>
	</div>

</section>