<section class="descubre ">
	<div class="btn-oficial-des line-this">
		<h6 style="color: #353636; font-weight: bold;" >
			<a style="color:#353636; " href="#">Descubre más</a>
		</h6>
	</div>
</section>

<section class="asesora">
	<div class="asesora-img">
		<div class="div2">
			<div class="div">
				<div class="text-img">
					<h6>PIJAMAS</h6>
					<h3 style="margin-bottom: 15px;">50% de<br> descuento<br>
					</h3>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
				</div>	
			</div>
		</div>
	</div>
	<div class="pijama1">
		<p>PIJAMAS</p>
	</div>
	<div class="pijama2">
		<p>PIJAMAS</p>
	</div>
</section>