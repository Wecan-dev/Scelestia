 <?php get_header(); ?>

 
 <?php  get_template_part('partials/banner'); ?>
 <?php  get_template_part('partials/comoda'); ?>
 <?php  get_template_part('partials/colecciones'); ?>
 <?php  get_template_part('partials/descuento'); ?>
 <?php  get_template_part('partials/asesora'); ?>
 <?php  get_template_part('partials/about'); ?>
 <?php  get_template_part('partials/widget'); ?>
 

 <?php get_footer(); ?>