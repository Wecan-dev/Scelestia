 <?php get_header(); ?>

<section class="not-found">
	<div class="text-error">

		<h3>LO SENTIMOS</h3>
		<p>No podemos encontrar la página que está buscando</p>
		<h2>404</h2>
		<h4>Te llevaremos de vuelta</h4>

		<div class="btn-black">
			<a href="<?php echo bloginfo('url')?>">Te llevamos al inicio</a>
		</div>
	</div>
</section>

  <?php get_footer(); ?>